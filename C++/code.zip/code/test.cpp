
cout<<"Rahatul Rabbi";
